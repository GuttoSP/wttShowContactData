var composeObserver = new MutationObserver(function(mutations)
{ 
	document.getElementsByClassName("_2YnE3")[0].click();	
});

function addObserverIfDesiredNodeAvailable() 
{
	var composeBox = document.querySelectorAll( "._3sh5K" )[1];
    if( !composeBox )
	{
        //The node we need does not exist yet.
        //Wait 500ms and try again
        window.setTimeout( addObserverIfDesiredNodeAvailable, 500 );
        return;
    }
	
    var config = {
		attributes: true, 
		childList: true, 
		characterData: true
	};
    composeObserver.observe(composeBox,config);	
	
}
addObserverIfDesiredNodeAvailable();